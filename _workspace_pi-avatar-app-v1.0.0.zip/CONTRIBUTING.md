# Contributing to Living Avatar System

Thank you for your interest in contributing to the Living Avatar System!

## How to Contribute

### Reporting Bugs
- Use the GitHub Issues tab
- Include your Pi model, OS version, and Python version
- Attach relevant log files from `~/.local/share/living-avatar/logs/`
- Describe steps to reproduce the issue

### Suggesting Features
- Open a GitHub Issue with the "enhancement" label
- Describe the feature and its use case
- Explain how it would benefit Pi 3 users

### Submitting Code
1. Fork the repository
2. Create a feature branch: `git checkout -b feature-name`
3. Make your changes
4. Test on Raspberry Pi 3
5. Commit with clear messages
6. Push to your fork
7. Open a Pull Request

## Development Setup

```bash
# Clone the repo
git clone https://github.com/theholybull/aipi.git
cd aipi

# Test on your Pi
chmod +x install.sh
./install.sh
```

## Code Style
- Python: Follow PEP 8
- JavaScript: Use ES6+ features
- HTML/CSS: Keep it clean and readable
- Comments: Explain "why", not "what"

## Testing
- Test on actual Raspberry Pi 3 hardware
- Verify performance (20+ FPS minimum)
- Check all controls work (mouse, touch, buttons)
- Test with different GLB models

## Performance Guidelines
- Keep polygon counts under 10k for Pi 3
- Optimize textures (max 2048x2048)
- Minimize shadow map resolution
- Test memory usage

## Documentation
- Update README.md for new features
- Add to SETUP_GUIDE.md for troubleshooting
- Include code comments
- Update CHANGELOG.md

## Questions?
Open a GitHub Discussion or Issue!