#!/bin/bash

# Living Avatar System - Stop Script

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

echo "Stopping Living Avatar System..."

# Kill server
if [ -f "$SCRIPT_DIR/.server.pid" ]; then
    SERVER_PID=$(cat "$SCRIPT_DIR/.server.pid")
    kill $SERVER_PID 2>/dev/null
    rm "$SCRIPT_DIR/.server.pid"
    echo "Server stopped (PID: $SERVER_PID)"
fi

# Kill browser
if [ -f "$SCRIPT_DIR/.browser.pid" ]; then
    BROWSER_PID=$(cat "$SCRIPT_DIR/.browser.pid")
    kill $BROWSER_PID 2>/dev/null
    rm "$SCRIPT_DIR/.browser.pid"
    echo "Browser stopped (PID: $BROWSER_PID)"
fi

# Fallback: kill any remaining processes
pkill -f "python3 app.py"
pkill -f "chromium-browser.*localhost:5000"

echo "Living Avatar System stopped."