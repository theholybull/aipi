#!/bin/bash

# Living Avatar System - Run Script

# Get the directory where the script is located
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
LOG_DIR="$SCRIPT_DIR/logs"
LOG_FILE="$LOG_DIR/avatar-$(date +%Y%m%d-%H%M%S).log"

# Create log directory if it doesn't exist
mkdir -p "$LOG_DIR"

# Activate virtual environment
source "$SCRIPT_DIR/venv/bin/activate"

# Start the Flask server in the background
echo "Starting Living Avatar System..." | tee -a "$LOG_FILE"
echo "Log file: $LOG_FILE" | tee -a "$LOG_FILE"

cd "$SCRIPT_DIR"
python3 app.py >> "$LOG_FILE" 2>&1 &
SERVER_PID=$!

# Wait for server to start
echo "Waiting for server to start..." | tee -a "$LOG_FILE"
sleep 3

# Open browser in kiosk mode (portrait orientation for 7" touchscreen)
echo "Opening browser..." | tee -a "$LOG_FILE"
chromium-browser \
    --kiosk \
    --noerrdialogs \
    --disable-infobars \
    --disable-session-crashed-bubble \
    --disable-restore-session-state \
    --window-size=800,1280 \
    http://localhost:5000 >> "$LOG_FILE" 2>&1 &

BROWSER_PID=$!

# Save PIDs for cleanup
echo $SERVER_PID > "$SCRIPT_DIR/.server.pid"
echo $BROWSER_PID > "$SCRIPT_DIR/.browser.pid"

echo "Living Avatar System is running!" | tee -a "$LOG_FILE"
echo "Server PID: $SERVER_PID" | tee -a "$LOG_FILE"
echo "Browser PID: $BROWSER_PID" | tee -a "$LOG_FILE"
echo "" | tee -a "$LOG_FILE"
echo "To stop the application, run: $SCRIPT_DIR/stop.sh" | tee -a "$LOG_FILE"

# Wait for browser to close
wait $BROWSER_PID

# Kill server when browser closes
if [ -f "$SCRIPT_DIR/.server.pid" ]; then
    kill $(cat "$SCRIPT_DIR/.server.pid") 2>/dev/null
    rm "$SCRIPT_DIR/.server.pid"
fi

echo "Living Avatar System stopped." | tee -a "$LOG_FILE"