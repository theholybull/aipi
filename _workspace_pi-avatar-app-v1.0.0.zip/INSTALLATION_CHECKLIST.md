# 📋 Living Avatar System - Installation Checklist

## Pre-Installation Requirements

- [ ] Raspberry Pi 3 (or newer) with Raspberry Pi OS installed
- [ ] Internet connection (for downloading dependencies)
- [ ] At least 500MB free disk space
- [ ] Display connected (7" touchscreen recommended)
- [ ] Keyboard/mouse or touchscreen for initial setup

---

## Installation Steps

### 1. Transfer Files to Pi
- [ ] Download `pi-avatar-app.zip` to your Raspberry Pi
- [ ] Extract the ZIP file: `unzip pi-avatar-app.zip`
- [ ] Navigate to folder: `cd pi-avatar-app`

### 2. Run Installer
- [ ] Make installer executable: `chmod +x install.sh`
- [ ] Run installer: `./install.sh`
- [ ] Wait for package installation (may take 5-10 minutes)
- [ ] Choose autostart option (y/n)

### 3. Verify Installation
- [ ] Desktop icon "Living Avatar" appears on desktop
- [ ] Installation directory exists: `ls ~/.local/share/living-avatar`
- [ ] Avatar file exists: `ls ~/.local/share/living-avatar/avatars/*.glb`

### 4. First Run
- [ ] Double-click "Living Avatar" desktop icon
- [ ] Browser opens in fullscreen/kiosk mode
- [ ] Avatar selection screen appears
- [ ] Click on avatar card
- [ ] 3D viewer loads successfully
- [ ] Avatar displays correctly
- [ ] FPS counter shows 20+ FPS

### 5. Test Controls
- [ ] Mouse/touch rotation works
- [ ] Zoom in/out works
- [ ] Pan camera works
- [ ] "Rotate Left" button works
- [ ] "Rotate Right" button works
- [ ] "Reset Camera" button works
- [ ] "Wireframe" toggle works
- [ ] "Back to Selection" button works

### 6. Performance Check
- [ ] FPS is 20+ (acceptable for Pi 3)
- [ ] No lag when rotating
- [ ] Smooth zoom in/out
- [ ] No browser crashes
- [ ] Memory usage is reasonable

---

## Post-Installation Tasks

### Optional: Add More Avatars
- [ ] Copy additional GLB files to: `~/.local/share/living-avatar/avatars/`
- [ ] Restart app or refresh selection screen
- [ ] Verify new avatars appear

### Optional: Customize Settings
- [ ] Edit background color in `viewer.html`
- [ ] Adjust performance settings if needed
- [ ] Change window size in `run.sh` for landscape mode

### Optional: Enable Autostart
- [ ] If not enabled during install, copy desktop file:
  ```bash
  cp ~/Desktop/LivingAvatar.desktop ~/.config/autostart/
  ```

---

## Troubleshooting Checklist

### If App Won't Start
- [ ] Check logs: `tail -f ~/.local/share/living-avatar/logs/*.log`
- [ ] Verify Python version: `python3 --version` (should be 3.7+)
- [ ] Check if port 5000 is free: `sudo netstat -tulpn | grep 5000`
- [ ] Try manual start: `~/.local/share/living-avatar/run.sh`

### If Browser Won't Open
- [ ] Verify Chromium installed: `which chromium-browser`
- [ ] Install if missing: `sudo apt-get install chromium-browser`
- [ ] Check X display: `echo $DISPLAY` (should show :0 or similar)

### If Avatar Won't Load
- [ ] Verify GLB file exists: `ls -lh ~/.local/share/living-avatar/avatars/`
- [ ] Check file permissions: `chmod 644 ~/.local/share/living-avatar/avatars/*.glb`
- [ ] Check browser console (F12) for errors
- [ ] Verify file size is reasonable (under 50MB)

### If Performance is Poor
- [ ] Close other applications
- [ ] Reduce shadow quality in `viewer.html`
- [ ] Disable shadows completely
- [ ] Use lower polygon count models (under 10k)
- [ ] Check CPU temperature: `vcgencmd measure_temp`

---

## System Information to Collect (for support)

```bash
# Pi Model
cat /proc/device-tree/model

# OS Version
cat /etc/os-release

# Python Version
python3 --version

# Chromium Version
chromium-browser --version

# Disk Space
df -h ~/.local/share/living-avatar

# Memory
free -h

# CPU Temperature
vcgencmd measure_temp

# Recent Logs
tail -50 ~/.local/share/living-avatar/logs/*.log
```

---

## Success Criteria

✅ **Installation Successful If:**
- Desktop icon appears and is clickable
- App starts without errors
- Avatar selection screen loads
- 3D viewer displays avatar correctly
- Controls are responsive
- FPS is 20+ on Pi 3
- No crashes or freezes

---

## Next Steps After Successful Installation

1. **Add More Avatars**: Copy GLB files to avatars directory
2. **Customize Appearance**: Edit HTML/CSS files
3. **Optimize Performance**: Adjust settings for your Pi model
4. **Add Features**: Implement animations, voice, etc.
5. **Create Backups**: Backup avatars directory regularly

---

## Quick Reference Commands

```bash
# Start app
~/.local/share/living-avatar/run.sh

# Stop app
~/.local/share/living-avatar/stop.sh

# View logs
tail -f ~/.local/share/living-avatar/logs/*.log

# Add avatar
cp /path/to/model.glb ~/.local/share/living-avatar/avatars/

# Uninstall
~/.local/share/living-avatar/uninstall.sh

# Reinstall
cd /path/to/pi-avatar-app && ./install.sh
```

---

## Support Resources

- **Setup Guide**: `SETUP_GUIDE.md` (detailed troubleshooting)
- **Quick Start**: `QUICK_START.txt` (basic commands)
- **README**: `README.md` (overview and features)
- **Logs**: `~/.local/share/living-avatar/logs/` (error messages)

---

**Installation Date**: _______________  
**Pi Model**: _______________  
**OS Version**: _______________  
**Status**: ⬜ Success  ⬜ Issues (see notes below)

**Notes**:
_________________________________________________________________
_________________________________________________________________
_________________________________________________________________