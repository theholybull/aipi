# Living Avatar System - Raspberry Pi Setup Guide

## 📋 Quick Start Cheat Sheet

### Installation (One-Time Setup)
```bash
# 1. Copy the pi-avatar-app folder to your Pi
# 2. Navigate to the folder
cd ~/Downloads/pi-avatar-app  # or wherever you copied it

# 3. Make install script executable
chmod +x install.sh

# 4. Run installer
./install.sh
```

### Running the App
```bash
# Option 1: Double-click the "Living Avatar" icon on your desktop

# Option 2: Run from terminal
~/.local/share/living-avatar/run.sh
```

### Stopping the App
```bash
# Option 1: Close the browser window (app will auto-stop)

# Option 2: Run stop script
~/.local/share/living-avatar/stop.sh
```

---

## 📁 File Structure After Installation

```
~/.local/share/living-avatar/
├── app.py                  # Flask backend server
├── run.sh                  # Start script
├── stop.sh                 # Stop script
├── uninstall.sh            # Uninstaller
├── venv/                   # Python virtual environment
├── templates/              # HTML templates
│   ├── index.html         # Avatar selection screen
│   └── viewer.html        # 3D viewer
├── avatars/               # PUT YOUR GLB FILES HERE
│   └── Character_in_Pink_Dre_1205175444_texture.glb
├── static/                # Static assets
│   └── thumbnails/        # Avatar thumbnails (optional)
└── logs/                  # Application logs
```

---

## 🎮 Adding New Avatars

### Step 1: Copy GLB Files
```bash
# Copy your GLB files to the avatars directory
cp /path/to/your/model.glb ~/.local/share/living-avatar/avatars/
```

### Step 2: Refresh the App
- Restart the app or click "Refresh" on the selection screen
- Your new avatar will appear automatically

### Naming Convention
- Use descriptive names: `female_ninja_red_hair.glb`
- Avoid spaces (use underscores instead)
- The filename becomes the avatar name (underscores become spaces)

---

## 🖥️ Display Configuration

### Portrait Mode (7" Touchscreen - 800x1280)
The app is optimized for portrait mode by default.

### Landscape Mode
To switch to landscape, edit `run.sh`:
```bash
# Change this line:
--window-size=800,1280 \

# To this:
--window-size=1280,800 \
```

### Fullscreen Kiosk Mode
Already enabled by default with `--kiosk` flag in `run.sh`

---

## 🔧 Troubleshooting

### App Won't Start
```bash
# Check if port 5000 is already in use
sudo netstat -tulpn | grep 5000

# Kill any process using port 5000
sudo kill -9 $(lsof -t -i:5000)

# Try starting again
~/.local/share/living-avatar/run.sh
```

### Browser Won't Open
```bash
# Check if chromium is installed
which chromium-browser

# If not installed:
sudo apt-get install chromium-browser
```

### Python Errors
```bash
# Reinstall dependencies in virtual environment
cd ~/.local/share/living-avatar
source venv/bin/activate
pip install --upgrade flask flask-cors
deactivate
```

### Avatar Not Loading
```bash
# Check if GLB file exists
ls -lh ~/.local/share/living-avatar/avatars/

# Check file permissions
chmod 644 ~/.local/share/living-avatar/avatars/*.glb

# Check logs
tail -f ~/.local/share/living-avatar/logs/*.log
```

---

## 📊 Performance Optimization for Pi 3

### Current Optimizations
- ✅ Reduced shadow map resolution (1024x1024)
- ✅ Limited pixel ratio to 2x max
- ✅ High-performance rendering mode
- ✅ Efficient lighting setup
- ✅ Optimized polygon counts

### If Performance is Slow
Edit `templates/viewer.html` and adjust:

```javascript
// Reduce shadow quality (line ~150)
directionalLight.shadow.mapSize.width = 512;  // was 1024
directionalLight.shadow.mapSize.height = 512; // was 1024

// Reduce pixel ratio (line ~130)
renderer.setPixelRatio(1); // was Math.min(window.devicePixelRatio, 2)

// Disable shadows completely (line ~132)
renderer.shadowMap.enabled = false; // was true
```

---

## 🔄 Updating the App

### Manual Update
```bash
# 1. Stop the app
~/.local/share/living-avatar/stop.sh

# 2. Backup your avatars
cp -r ~/.local/share/living-avatar/avatars ~/avatar-backup

# 3. Uninstall
~/.local/share/living-avatar/uninstall.sh

# 4. Reinstall with new version
cd /path/to/new/pi-avatar-app
./install.sh

# 5. Restore avatars
cp ~/avatar-backup/* ~/.local/share/living-avatar/avatars/
```

---

## 🗑️ Uninstalling

```bash
# Run uninstall script
~/.local/share/living-avatar/uninstall.sh

# This will remove:
# - Installation directory
# - Desktop icon
# - Autostart entry
# - All app files (but will ask for confirmation)
```

---

## 🐛 Viewing Logs

```bash
# View latest log
tail -f ~/.local/share/living-avatar/logs/*.log

# View all logs
ls -lh ~/.local/share/living-avatar/logs/

# Clear old logs
rm ~/.local/share/living-avatar/logs/*.log
```

---

## 🎯 Keyboard Shortcuts (in viewer)

- **Left Click + Drag**: Rotate camera around avatar
- **Right Click + Drag**: Pan camera
- **Scroll Wheel**: Zoom in/out
- **Escape**: Exit fullscreen (if not in kiosk mode)

---

## 📱 Touchscreen Controls

- **Single Finger Drag**: Rotate camera
- **Two Finger Pinch**: Zoom in/out
- **Two Finger Drag**: Pan camera
- **Tap Buttons**: Use on-screen controls

---

## 🔐 Security Notes

- App runs on localhost only (not accessible from network)
- No external connections except CDN for Three.js library
- All avatar files stored locally
- No data collection or telemetry

---

## 💡 Tips & Tricks

### Faster Startup
Add to autostart during installation for instant availability on boot

### Multiple Avatars
Organize avatars in subfolders (app will scan recursively in future versions)

### Custom Thumbnails
Place PNG files in `static/thumbnails/` with same name as GLB file

### Background Color
Edit `viewer.html` line ~120 to change background:
```javascript
scene.background = new THREE.Color(0xf5f5f5); // Change hex color
```

---

## 📞 Support

### Check Logs First
```bash
tail -50 ~/.local/share/living-avatar/logs/*.log
```

### System Info
```bash
# Pi model
cat /proc/device-tree/model

# OS version
cat /etc/os-release

# Python version
python3 --version

# Chromium version
chromium-browser --version
```

---

## 🎨 Customization

### Change App Colors
Edit `templates/index.html` and `templates/viewer.html` CSS sections

### Add More Controls
Edit `templates/viewer.html` JavaScript section

### Change Port
Edit `app.py` line ~100:
```python
app.run(host='0.0.0.0', port=5000, debug=False, threaded=True)
```

---

## ✅ Installation Checklist

- [ ] Copied pi-avatar-app folder to Pi
- [ ] Made install.sh executable (`chmod +x install.sh`)
- [ ] Ran installer (`./install.sh`)
- [ ] Desktop icon created
- [ ] Copied GLB file to avatars directory
- [ ] Tested app by double-clicking desktop icon
- [ ] Avatar loads and displays correctly
- [ ] Controls work (rotate, zoom, etc.)
- [ ] Performance is acceptable (20+ FPS)

---

## 🚀 Next Steps

Once the basic app is working:
1. Add more avatar models
2. Implement idle animations
3. Add voice synthesis
4. Create personality modes
5. Add clothing/hair customization
6. Integrate weather-based clothing changes

---

**Installation Location**: `~/.local/share/living-avatar/`  
**Desktop Icon**: `~/Desktop/LivingAvatar.desktop`  
**Logs**: `~/.local/share/living-avatar/logs/`  
**Avatars**: `~/.local/share/living-avatar/avatars/`