# GitHub Repository Setup Guide

This guide helps you push the Living Avatar System to your GitHub repository.

## Initial Setup

### 1. Navigate to Project Directory
```bash
cd /path/to/pi-avatar-app
```

### 2. Initialize Git Repository (if not already done)
```bash
git init
```

### 3. Add Remote Repository
```bash
git remote add origin https://github.com/theholybull/aipi.git
```

### 4. Configure Git (if first time)
```bash
git config user.name "Your Name"
git config user.email "your.email@example.com"
```

## Pushing to GitHub

### 1. Add All Files
```bash
git add .
```

### 2. Commit Changes
```bash
git commit -m "Initial commit: Living Avatar System v1.0.0"
```

### 3. Push to GitHub
```bash
# If main branch
git branch -M main
git push -u origin main

# Or if master branch
git push -u origin master
```

## File Structure for GitHub

```
aipi/
├── .gitignore                      # Ignore unnecessary files
├── LICENSE                         # MIT License
├── README.md                       # Main documentation
├── CHANGELOG.md                    # Version history
├── CONTRIBUTING.md                 # Contribution guidelines
├── SETUP_GUIDE.md                 # Detailed setup
├── QUICK_START.txt                # Quick reference
├── INSTALLATION_CHECKLIST.md      # Installation steps
├── install.sh                     # Installer script
├── run.sh                         # Run script
├── stop.sh                        # Stop script
├── uninstall.sh                   # Uninstall script
├── app.py                         # Flask backend
├── templates/
│   ├── index.html                # Selection screen
│   └── viewer.html               # 3D viewer
├── avatars/
│   └── .gitkeep                  # Keep directory in git
└── static/
    └── thumbnails/
        └── .gitkeep              # Keep directory in git
```

## Important Notes

### Files NOT Committed (via .gitignore)
- `venv/` - Virtual environment
- `logs/` - Log files
- `*.pyc` - Python bytecode
- `__pycache__/` - Python cache
- `.server.pid` - Runtime files
- `.browser.pid` - Runtime files
- `avatars/*.glb` - User's avatar files (too large)

### Files TO Commit
- All scripts (.sh files)
- All documentation (.md files)
- Python source (app.py)
- HTML templates
- .gitkeep files (to preserve directory structure)

## Creating a Release

### 1. Tag the Version
```bash
git tag -a v1.0.0 -m "Release version 1.0.0"
git push origin v1.0.0
```

### 2. Create Release on GitHub
1. Go to: https://github.com/theholybull/aipi/releases
2. Click "Draft a new release"
3. Choose tag: v1.0.0
4. Release title: "Living Avatar System v1.0.0"
5. Description: Copy from CHANGELOG.md
6. Attach: pi-avatar-app.zip (if you want downloadable package)
7. Click "Publish release"

## Updating the Repository

### After Making Changes
```bash
# Check what changed
git status

# Add specific files
git add file1.py file2.html

# Or add all changes
git add .

# Commit with descriptive message
git commit -m "Add feature: idle animations"

# Push to GitHub
git push origin main
```

## Branch Strategy

### Main Branch
- Stable, tested code only
- Ready for users to clone and install

### Development Branch (optional)
```bash
# Create dev branch
git checkout -b development

# Make changes, commit, push
git push origin development

# Merge to main when ready
git checkout main
git merge development
git push origin main
```

## GitHub Repository Settings

### Recommended Settings
1. **Description**: "3D Avatar System for Raspberry Pi 3 with touchscreen support"
2. **Topics**: `raspberry-pi`, `3d-avatar`, `threejs`, `flask`, `python`, `touchscreen`
3. **License**: MIT
4. **README**: Enabled (README.md)
5. **Issues**: Enabled
6. **Discussions**: Enabled (optional)
7. **Wiki**: Disabled (use docs in repo)

### Branch Protection (optional)
1. Go to Settings → Branches
2. Add rule for `main` branch
3. Enable: "Require pull request reviews before merging"

## README Badges

Already included in README.md:
- License badge
- Python version badge
- Raspberry Pi badge
- Status badge

## Documentation Structure

```
Main README.md (overview, quick start)
    ├── SETUP_GUIDE.md (detailed setup)
    ├── QUICK_START.txt (command reference)
    ├── INSTALLATION_CHECKLIST.md (step-by-step)
    ├── CONTRIBUTING.md (how to contribute)
    └── CHANGELOG.md (version history)
```

## Useful Git Commands

```bash
# Check status
git status

# View commit history
git log --oneline

# View remote URL
git remote -v

# Pull latest changes
git pull origin main

# Discard local changes
git checkout -- filename

# Create new branch
git checkout -b feature-name

# Switch branches
git checkout main

# Delete branch
git branch -d feature-name

# View all branches
git branch -a
```

## Troubleshooting

### Large Files Error
If you accidentally committed large GLB files:
```bash
# Remove from git but keep locally
git rm --cached avatars/*.glb
git commit -m "Remove large GLB files"
git push origin main
```

### Authentication Issues
```bash
# Use personal access token instead of password
# Generate at: https://github.com/settings/tokens
```

### Merge Conflicts
```bash
# Pull latest changes
git pull origin main

# Resolve conflicts in files
# Then commit
git add .
git commit -m "Resolve merge conflicts"
git push origin main
```

## Next Steps

1. ✅ Push code to GitHub
2. ✅ Create v1.0.0 release
3. ✅ Add repository description and topics
4. ✅ Enable Issues and Discussions
5. ✅ Share repository link
6. 🔄 Continue development
7. 🔄 Accept contributions
8. 🔄 Release updates

---

**Repository URL**: https://github.com/theholybull/aipi