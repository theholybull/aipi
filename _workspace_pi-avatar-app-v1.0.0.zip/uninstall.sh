#!/bin/bash

# Living Avatar System - Uninstall Script

INSTALL_DIR="$HOME/.local/share/living-avatar"
DESKTOP_FILE="$HOME/Desktop/LivingAvatar.desktop"
AUTOSTART_FILE="$HOME/.config/autostart/LivingAvatar.desktop"

echo "=========================================="
echo "Living Avatar System - Uninstall"
echo "=========================================="
echo ""

read -p "Are you sure you want to uninstall? (y/n) " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo "Uninstall cancelled."
    exit 0
fi

# Stop the application if running
if [ -f "$INSTALL_DIR/stop.sh" ]; then
    echo "Stopping application..."
    "$INSTALL_DIR/stop.sh"
fi

# Remove desktop icon
if [ -f "$DESKTOP_FILE" ]; then
    echo "Removing desktop icon..."
    rm "$DESKTOP_FILE"
fi

# Remove autostart entry
if [ -f "$AUTOSTART_FILE" ]; then
    echo "Removing autostart entry..."
    rm "$AUTOSTART_FILE"
fi

# Remove installation directory
if [ -d "$INSTALL_DIR" ]; then
    echo "Removing installation directory..."
    rm -rf "$INSTALL_DIR"
fi

echo ""
echo "Living Avatar System has been uninstalled."
echo ""