# Changelog

All notable changes to the Living Avatar System will be documented in this file.

## [1.0.0] - 2024-12-05

### Added
- Initial release of Living Avatar System for Raspberry Pi 3
- 3D avatar viewer with Three.js rendering engine
- Avatar selection screen with automatic GLB scanning
- Flask backend server for avatar management
- Touch-friendly controls optimized for 7" touchscreen
- Desktop icon for easy launch
- Automatic installation script with dependency management
- Kiosk mode for dedicated display setup
- Performance optimizations for Raspberry Pi 3:
  - Reduced shadow map resolution (1024x1024)
  - Limited pixel ratio to 2x maximum
  - High-performance rendering mode
  - Efficient lighting setup
- FPS counter and performance monitoring
- Comprehensive documentation:
  - README.md - Project overview
  - SETUP_GUIDE.md - Detailed setup and troubleshooting
  - QUICK_START.txt - Quick reference guide
  - INSTALLATION_CHECKLIST.md - Step-by-step verification
- Run/stop/uninstall scripts
- Logging system for debugging
- Support for portrait mode (800x1280) and landscape mode

### Features
- Interactive camera controls (rotate, pan, zoom)
- Wireframe toggle for model inspection
- Automatic model centering and scaling
- Shadow rendering with soft shadows
- Multiple lighting setup (ambient, directional, fill, back)
- Responsive design for various screen sizes
- Automatic avatar discovery from avatars directory

### Technical Details
- Python 3.7+ with Flask backend
- Three.js r160 for 3D rendering
- Chromium browser in kiosk mode
- Virtual environment for Python dependencies
- No external pip installations (uses venv to avoid system breakage)

### Known Limitations
- Optimized for models under 10k polygons
- Best performance with textures under 2048x2048
- Target FPS: 20-30 on Raspberry Pi 3
- Requires Chromium browser

## [Unreleased]

### Planned Features
- Idle animations (breathing, blinking, subtle movements)
- Talking/lip-sync system
- Voice synthesis with British/Irish accent
- Personality modes (normal, playful, serious, sarcastic, naughty)
- Hair and clothing customization system
- Weather-based clothing changes
- Time-based outfit selection
- Multiple avatar support with hot-swapping
- Animation timeline editor
- Custom expression creator
- Voice command integration
- Gesture recognition for touchscreen
- Multi-language support

### Future Optimizations
- WebGL2 rendering improvements
- Texture compression
- Level-of-detail (LOD) system
- Occlusion culling
- Instanced rendering for accessories
- Progressive model loading