#!/usr/bin/env python3
"""
Living Avatar System - Flask Backend
Optimized for Raspberry Pi 3
"""

from flask import Flask, render_template, jsonify, request, send_from_directory
from flask_cors import CORS
import os
import json
from pathlib import Path

app = Flask(__name__)
CORS(app)

# Configuration
BASE_DIR = Path(__file__).parent
AVATARS_DIR = BASE_DIR / 'avatars'
STATIC_DIR = BASE_DIR / 'static'

# Ensure directories exist
AVATARS_DIR.mkdir(exist_ok=True)
STATIC_DIR.mkdir(exist_ok=True)

# Avatar database
AVATAR_DATABASE = {
    'characters': [
        {
            'id': 'character_pink_dress',
            'name': 'Character in Pink Dress',
            'file': 'Character_in_Pink_Dre_1205175444_texture.glb',
            'thumbnail': 'thumbnails/character_pink_dress.png',
            'description': 'Female character in pink dress',
            'category': 'female'
        }
    ],
    'hair_styles': [],
    'clothing': []
}

def scan_avatars():
    """Scan avatars directory and update database"""
    avatars = []
    
    # Scan for GLB files
    for glb_file in AVATARS_DIR.glob('*.glb'):
        avatar_id = glb_file.stem
        avatars.append({
            'id': avatar_id,
            'name': avatar_id.replace('_', ' ').title(),
            'file': glb_file.name,
            'thumbnail': f'thumbnails/{avatar_id}.png',
            'description': f'3D Avatar: {avatar_id}',
            'category': 'custom'
        })
    
    return avatars

@app.route('/')
def index():
    """Main page - Avatar selection screen"""
    return render_template('index.html')

@app.route('/viewer')
def viewer():
    """3D Avatar viewer"""
    avatar_id = request.args.get('avatar', 'character_pink_dress')
    return render_template('viewer.html', avatar_id=avatar_id)

@app.route('/api/avatars')
def get_avatars():
    """Get list of available avatars"""
    # Combine database avatars with scanned avatars
    all_avatars = AVATAR_DATABASE['characters'] + scan_avatars()
    
    # Remove duplicates
    seen = set()
    unique_avatars = []
    for avatar in all_avatars:
        if avatar['id'] not in seen:
            seen.add(avatar['id'])
            unique_avatars.append(avatar)
    
    return jsonify({
        'avatars': unique_avatars,
        'total': len(unique_avatars)
    })

@app.route('/api/avatar/<avatar_id>')
def get_avatar(avatar_id):
    """Get specific avatar details"""
    all_avatars = AVATAR_DATABASE['characters'] + scan_avatars()
    
    for avatar in all_avatars:
        if avatar['id'] == avatar_id:
            return jsonify(avatar)
    
    return jsonify({'error': 'Avatar not found'}), 404

@app.route('/avatars/<path:filename>')
def serve_avatar(filename):
    """Serve avatar GLB files"""
    return send_from_directory(AVATARS_DIR, filename)

@app.route('/static/<path:filename>')
def serve_static(filename):
    """Serve static files"""
    return send_from_directory(STATIC_DIR, filename)

@app.route('/api/health')
def health():
    """Health check endpoint"""
    return jsonify({
        'status': 'ok',
        'avatars_dir': str(AVATARS_DIR),
        'avatars_count': len(scan_avatars())
    })

if __name__ == '__main__':
    print("=" * 50)
    print("Living Avatar System - Starting")
    print("=" * 50)
    print(f"Avatars directory: {AVATARS_DIR}")
    print(f"Available avatars: {len(scan_avatars())}")
    print("=" * 50)
    print("Server starting on http://localhost:5000")
    print("=" * 50)
    
    # Run Flask server
    # Debug=False for production on Pi
    app.run(host='0.0.0.0', port=5000, debug=False, threaded=True)