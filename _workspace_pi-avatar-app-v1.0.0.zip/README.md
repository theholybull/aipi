# Living Avatar System for Raspberry Pi 3

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Python 3.7+](https://img.shields.io/badge/python-3.7+-blue.svg)](https://www.python.org/downloads/)
[![Raspberry Pi 3](https://img.shields.io/badge/Raspberry%20Pi-3%2B-red.svg)](https://www.raspberrypi.org/)

A 3D avatar viewer system optimized for Raspberry Pi 3 with 7" touchscreen (800x1280 portrait mode). Display and interact with 3D avatars using an intuitive touch interface.

![Living Avatar System](https://img.shields.io/badge/status-stable-green.svg)

## 🌟 Features

- ✅ **3D Avatar Viewer** - Full Three.js rendering engine with WebGL
- ✅ **Avatar Selection Screen** - Beautiful grid layout with automatic scanning
- ✅ **Touch-Friendly Controls** - Optimized for 7" touchscreen displays
- ✅ **Pi 3 Optimized** - Runs smoothly at 20-30 FPS on Raspberry Pi 3
- ✅ **Desktop Icon** - One-click launch from desktop
- ✅ **Automatic Discovery** - Scans and displays all GLB files automatically
- ✅ **Kiosk Mode** - Fullscreen dedicated display mode
- ✅ **Performance Monitoring** - Real-time FPS counter
- ✅ **Easy Installation** - One-command setup with all dependencies

## 🚀 Quick Install

```bash
# Clone the repository
git clone https://github.com/theholybull/aipi.git
cd aipi

# Make installer executable
chmod +x install.sh

# Run installer
./install.sh
```

Then double-click the "Living Avatar" icon on your desktop!

## 📋 Requirements

- **Hardware**: Raspberry Pi 3 (or newer)
- **OS**: Raspberry Pi OS (Debian-based)
- **Display**: 7" touchscreen (optional, works with any display)
- **Software**: Python 3.7+, Chromium browser
- **Storage**: 500MB free disk space

## 📁 Project Structure

```
aipi/
├── install.sh                      # One-command installer
├── run.sh                          # Start the application
├── stop.sh                         # Stop the application
├── uninstall.sh                    # Complete uninstaller
├── app.py                          # Flask backend server
├── templates/
│   ├── index.html                 # Avatar selection screen
│   └── viewer.html                # 3D avatar viewer
├── avatars/                        # Place your GLB files here
├── static/
│   └── thumbnails/                # Optional avatar thumbnails
├── SETUP_GUIDE.md                 # Detailed setup instructions
├── QUICK_START.txt                # Quick reference guide
├── INSTALLATION_CHECKLIST.md      # Step-by-step verification
├── CHANGELOG.md                   # Version history
├── CONTRIBUTING.md                # Contribution guidelines
└── LICENSE                        # MIT License

```

## 🎮 Usage

### Starting the App
```bash
# Method 1: Desktop icon
Double-click "Living Avatar" on desktop

# Method 2: Command line
~/.local/share/living-avatar/run.sh
```

### Adding Avatars
```bash
# Copy GLB files to avatars directory
cp /path/to/your/model.glb ~/.local/share/living-avatar/avatars/

# Restart app or refresh selection screen
```

### Stopping the App
```bash
# Method 1: Close browser window (auto-stops)

# Method 2: Command line
~/.local/share/living-avatar/stop.sh
```

## 🎯 Controls

### Mouse/Touchpad
- **Left Click + Drag**: Rotate camera around avatar
- **Right Click + Drag**: Pan camera position
- **Scroll Wheel**: Zoom in/out

### Touchscreen
- **Single Finger Drag**: Rotate camera
- **Two Finger Pinch**: Zoom in/out
- **Two Finger Drag**: Pan camera

### On-Screen Buttons
- **← Rotate / Rotate →**: Spin avatar left/right
- **Zoom + / Zoom -**: Quick zoom controls
- **Reset View**: Return to default camera position
- **Wireframe**: Toggle wireframe mode for model inspection

## ⚡ Performance

Optimized for Raspberry Pi 3:
- **Target FPS**: 20-30 FPS
- **Shadow Quality**: Reduced to 1024x1024 for performance
- **Pixel Ratio**: Limited to 2x maximum
- **Recommended Models**: Under 10k polygons
- **Texture Size**: Max 2048x2048 for best performance

## 🔧 Troubleshooting

### Quick Fixes
```bash
# View logs
tail -f ~/.local/share/living-avatar/logs/*.log

# Restart app
~/.local/share/living-avatar/stop.sh
~/.local/share/living-avatar/run.sh

# Check if port is in use
sudo netstat -tulpn | grep 5000

# Reinstall
~/.local/share/living-avatar/uninstall.sh
cd /path/to/aipi && ./install.sh
```

See [SETUP_GUIDE.md](SETUP_GUIDE.md) for detailed troubleshooting.

## 📚 Documentation

- **[SETUP_GUIDE.md](SETUP_GUIDE.md)** - Comprehensive setup and troubleshooting
- **[QUICK_START.txt](QUICK_START.txt)** - Quick reference commands
- **[INSTALLATION_CHECKLIST.md](INSTALLATION_CHECKLIST.md)** - Step-by-step verification
- **[CHANGELOG.md](CHANGELOG.md)** - Version history and updates
- **[CONTRIBUTING.md](CONTRIBUTING.md)** - How to contribute

## 🗑️ Uninstall

```bash
~/.local/share/living-avatar/uninstall.sh
```

This removes:
- Installation directory
- Desktop icon
- Autostart entry
- All application files

## 🛣️ Roadmap

### Planned Features
- [ ] Idle animations (breathing, blinking, subtle movements)
- [ ] Talking/lip-sync system
- [ ] Voice synthesis with British/Irish accent
- [ ] Personality modes (normal, playful, serious, sarcastic, naughty)
- [ ] Hair and clothing customization
- [ ] Weather-based outfit changes
- [ ] Time-based clothing selection
- [ ] Animation timeline editor
- [ ] Voice command integration

See [CHANGELOG.md](CHANGELOG.md) for full roadmap.

## 🤝 Contributing

Contributions are welcome! Please read [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines.

### How to Contribute
1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test on Raspberry Pi 3
5. Submit a pull request

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Credits

Built with:
- **[Three.js](https://threejs.org/)** - 3D rendering engine
- **[Flask](https://flask.palletsprojects.com/)** - Python web framework
- **[Chromium](https://www.chromium.org/)** - Browser engine

## 📞 Support

- **Issues**: [GitHub Issues](https://github.com/theholybull/aipi/issues)
- **Discussions**: [GitHub Discussions](https://github.com/theholybull/aipi/discussions)
- **Documentation**: See docs in this repository

## 🌐 Repository

**GitHub**: [https://github.com/theholybull/aipi](https://github.com/theholybull/aipi)

---

Made with ❤️ for the Raspberry Pi community