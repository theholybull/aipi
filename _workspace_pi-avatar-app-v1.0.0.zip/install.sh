#!/bin/bash

# Living Avatar System - Raspberry Pi Installer
# For Raspberry Pi 3 running Raspberry Pi OS (Debian-based)

set -e

echo "=========================================="
echo "Living Avatar System - Installation"
echo "=========================================="
echo ""

# Check if running on Raspberry Pi
if [ ! -f /proc/device-tree/model ]; then
    echo "Warning: This doesn't appear to be a Raspberry Pi"
    read -p "Continue anyway? (y/n) " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        exit 1
    fi
fi

# Get the directory where the script is located
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
INSTALL_DIR="$HOME/.local/share/living-avatar"
DESKTOP_FILE="$HOME/Desktop/LivingAvatar.desktop"

echo "Installation directory: $INSTALL_DIR"
echo ""

# Update package list
echo "Updating package list..."
sudo apt-get update

# Install system dependencies (avoiding pip install issues)
echo "Installing system dependencies..."
sudo apt-get install -y \
    python3-venv \
    python3-pip \
    chromium-browser \
    xdg-utils \
    libgles2-mesa \
    libgbm1

# Create installation directory
echo "Creating installation directory..."
mkdir -p "$INSTALL_DIR"
mkdir -p "$INSTALL_DIR/avatars"
mkdir -p "$INSTALL_DIR/logs"

# Copy application files
echo "Copying application files..."
cp -r "$SCRIPT_DIR"/* "$INSTALL_DIR/"

# Create Python virtual environment
echo "Creating Python virtual environment..."
cd "$INSTALL_DIR"
python3 -m venv venv

# Activate virtual environment and install Python packages
echo "Installing Python packages in virtual environment..."
source venv/bin/activate
pip install --upgrade pip
pip install flask flask-cors

# Make run script executable
chmod +x "$INSTALL_DIR/run.sh"

# Create desktop icon
echo "Creating desktop icon..."
cat > "$DESKTOP_FILE" << EOF
[Desktop Entry]
Version=1.0
Type=Application
Name=Living Avatar
Comment=3D Avatar System
Exec=$INSTALL_DIR/run.sh
Icon=$INSTALL_DIR/icon.png
Terminal=false
Categories=Graphics;3DGraphics;
EOF

chmod +x "$DESKTOP_FILE"

# Create icon (simple placeholder - you can replace with actual icon)
echo "Creating application icon..."
cat > "$INSTALL_DIR/icon.png.base64" << 'EOF'
iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAACXBIWXMAAAsTAAALEwEAmpwYAAADG0lEQVR4nO2bS2sUQRSFv4kxGhVFRRQfqOCCuHDhQlz4A1z5AxT8Bf4BF4ILFyq4cOFCBRciuHDhQkVQUVFRfCCKr6iJJhqNmphMpqe6p6Znuqt7uqtnMnBgIJnprnvPqVt1q+oWZGRkZGRkZGT8RzQBvcAQMAqMA1+BKWDGfk7Z30btmF57TmPaE+kEhoEF/FkA7gNdaU6+FbgLLBKcReA2sDnpyW8BXhKeBWBv0hPfDXwl+kVoT2ribcBnkuMz0JrExHuAnyTLD6AzzonXA1MkzxTQEMfEG4FvpMM3YF0cE/9Eenwk+skvAr0kSy8wH/XEHwHrSZb1wOOoJ34n7QlY7kQ98RvAWtJlLXAj6onfTHsClptRT/xq2hOw9Ec98UtpT8ByKY4beQr4knZjNl+IYeJtwDfSZwpoC3vyO4Bp0mcaK6fCZBfwg/SZBnaGOfFO4Cfp8xPYEebEO0ifn1gFVhgcAv6QPn+AQ2FO/BjpM2bPD4WDpM8B/+2vAv4CP0mXn8Aq/+2vAv5i1V1p8hf/ya8C5rEuXGkyD8z5b38VMA/0kB49eE5+FTCHdeFKkzk8J78KmMW6cKXJLJ6TXwXMYF240mQGz8mvAqaxLlxpMo3n5FcBU1gXrjSZwnPyq4BJrAtXmkziOflVwATWhStNJvCc/CrgK9aFK02+4jn5VcAXrAtXmnzBc/KrgM9YF640+Yzn5FcBn7AuXGnyCc/JrwI+Yl240uQjnpNfBYxhXbjSZAzPya8CPmBduNLkA56TXwW8x7pwpcl7PCe/CniHdeFKk3d4Tn4V8BbrwpUmb/Gc/CrgDdaFK03e4Dn5VcBrrAtXmrzGc/KrgFdYF640eYXn5FcBL7EuXGnyEs/JrwJeYF240uQFnpNfBTzHunClyXM8J78KeIZ14UqTZ3hOfhXwFOvClSZP8Zz8KuAJ1oUrTZ7gOflVwGOsC1eaPMZz8quAR1gXrjR5hOfkVwEPsS5cafIQz8mvAh5gXbjS5AGek18F3Me6cKXJfTwnvwq4h3XhSpN7eE5+FXCXeOgm48/lDvZNMSMjIyMjIyMjg+T4B+2wcq/T6+kLAAAAAElFTkSuQmCC
EOF

base64 -d "$INSTALL_DIR/icon.png.base64" > "$INSTALL_DIR/icon.png"
rm "$INSTALL_DIR/icon.png.base64"

# Create autostart entry (optional)
read -p "Do you want the app to start automatically on boot? (y/n) " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    mkdir -p "$HOME/.config/autostart"
    cp "$DESKTOP_FILE" "$HOME/.config/autostart/"
    echo "Autostart enabled"
fi

echo ""
echo "=========================================="
echo "Installation Complete!"
echo "=========================================="
echo ""
echo "The Living Avatar System has been installed to:"
echo "$INSTALL_DIR"
echo ""
echo "You can start it by:"
echo "1. Double-clicking the 'Living Avatar' icon on your desktop"
echo "2. Running: $INSTALL_DIR/run.sh"
echo ""
echo "Logs will be saved to: $INSTALL_DIR/logs/"
echo ""
echo "To uninstall, run: $INSTALL_DIR/uninstall.sh"
echo ""